#!/bin/bash

# 🚀 Быстрая настройка HTTPS для Agent System
# Этот скрипт настроит HTTPS за 2 минуты

echo "🚀 Быстрая настройка HTTPS..."
echo "============================="

# Загружаем файлы на сервер
echo "📤 Загружаем конфигурацию на сервер..."
scp nginx-https.conf setup-https.sh root@152.53.227.37:/root/

# Подключаемся к серверу и запускаем настройку
echo "🔧 Запускаем настройку на сервере..."
ssh root@152.53.227.37 << 'ENDSSH'
cd /root
chmod +x setup-https.sh
./setup-https.sh
ENDSSH

echo ""
echo "🎉 HTTPS настроен!"
echo "=================="
echo ""
echo "🌐 Теперь доступно по HTTPS:"
echo "   • https://agent.152.53.227.37.nip.io"
echo "   • https://api.152.53.227.37.nip.io" 
echo "   • https://tools.152.53.227.37.nip.io"
echo ""
echo "✅ Готово!"