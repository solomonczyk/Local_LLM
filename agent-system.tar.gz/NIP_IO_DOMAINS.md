# 🌐 Agent System - nip.io Домены

## ✅ Доступные домены для Agent System

Ваша агентская система теперь доступна через удобные nip.io домены!

### 🎯 Основные сервисы

| Сервис | nip.io Домен | Прямой IP | Описание |
|--------|--------------|-----------|----------|
| **🖥️ Web UI** | http://152.53.227.37.nip.io:7865 | http://152.53.227.37:7865 | Веб-интерфейс агентской системы |
| **🤖 LLM API** | http://152.53.227.37.nip.io:8002 | http://152.53.227.37:8002 | Enhanced LLM API с памятью |
| **🔧 Tools API** | http://152.53.227.37.nip.io:8003 | http://152.53.227.37:8003 | API для инструментов и файлов |

### 🎨 Красивые поддомены

| Сервис | Красивый домен | Описание |
|--------|----------------|----------|
| **Agent UI** | http://agent.152.53.227.37.nip.io:7865 | Главный интерфейс |
| **LLM API** | http://llm.152.53.227.37.nip.io:8002 | API языковой модели |
| **Tools API** | http://tools.152.53.227.37.nip.io:8003 | API инструментов |
| **API Gateway** | http://api.152.53.227.37.nip.io:8002 | Основной API |

### 🔗 Специальные endpoints

#### Health Checks
- **LLM Health**: http://152.53.227.37.nip.io:8002/health
- **Tools Health**: http://152.53.227.37.nip.io:8003/health
- **System Status**: Доступен через UI

#### API Documentation
- **LLM API Docs**: http://152.53.227.37.nip.io:8002/docs
- **Tools API Docs**: http://152.53.227.37.nip.io:8003/docs
- **OpenAI Compatible**: http://152.53.227.37.nip.io:8002/v1

## 🚀 Как использовать

### 1. Веб-интерфейс
Откройте в браузере: **http://agent.152.53.227.37.nip.io:7865**

Функции:
- ⚙️ Настройка режимов Consilium (FAST/STANDARD/CRITICAL)
- 🧠 Smart routing агентов
- 📁 Загрузка файлов и контекста
- 📊 Мониторинг статуса системы
- 🎯 Выполнение задач через multi-agent систему

### 2. API Integration

#### LLM API (OpenAI Compatible)
```bash
curl -X POST http://llm.152.53.227.37.nip.io:8002/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "enhanced-model",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

#### Tools API
```bash
# Чтение файла
curl -X POST http://tools.152.53.227.37.nip.io:8003/tools/read_file \
  -H "Content-Type: application/json" \
  -d '{"path": "example.txt"}'

# Системная информация
curl -X POST http://tools.152.53.227.37.nip.io:8003/tools/system_info \
  -H "Content-Type: application/json" \
  -d '{"info_type": "disks"}'
```

## 🔧 Что такое nip.io?

**nip.io** - это бесплатный сервис wildcard DNS, который автоматически резолвит любой IP-адрес:

- `152.53.227.37.nip.io` → `152.53.227.37`
- `agent.152.53.227.37.nip.io` → `152.53.227.37`
- `любое-имя.152.53.227.37.nip.io` → `152.53.227.37`

### Преимущества:
✅ **Бесплатно** - никаких регистраций и оплат  
✅ **Мгновенно** - работает сразу без настройки  
✅ **Удобно** - легче запомнить чем IP  
✅ **Гибко** - можно создавать любые поддомены  

### Проверка DNS:
```bash
nslookup 152.53.227.37.nip.io
# Результат: 152.53.227.37

nslookup agent.152.53.227.37.nip.io  
# Результат: 152.53.227.37
```

## 📱 Мобильный доступ

Все домены работают и на мобильных устройствах:
- **Телефон**: http://agent.152.53.227.37.nip.io:7865
- **Планшет**: http://agent.152.53.227.37.nip.io:7865

## 🔐 Безопасность

⚠️ **Важно**: Все соединения идут по HTTP (не HTTPS)
- Для продакшена рекомендуется настроить SSL/TLS
- Не передавайте чувствительные данные без шифрования
- Рассмотрите использование VPN для доступа

## 🎯 Рекомендуемые закладки

Добавьте в закладки браузера:

1. **🏠 Agent System** - http://agent.152.53.227.37.nip.io:7865
2. **📊 LLM Health** - http://llm.152.53.227.37.nip.io:8002/health  
3. **🔧 Tools Health** - http://tools.152.53.227.37.nip.io:8003/health
4. **📚 API Docs** - http://llm.152.53.227.37.nip.io:8002/docs

---

**Готово!** 🎉 Теперь у вас есть красивые и удобные домены для доступа к агентской системе!