# 🧠 Настройка PostgreSQL памяти для агента

## 📋 Требования

1. **PostgreSQL сервер** (версия 12+)
2. **Python библиотека**: `pip install psycopg2-binary`
3. **База данных** для агента

## 🚀 Быстрая настройка

### 1. Установка PostgreSQL (если не установлен)

#### Windows:
```bash
# Скачать с https://www.postgresql.org/download/windows/
# Или через Chocolatey:
choco install postgresql
```

#### Docker (рекомендуется для тестирования):
```bash
docker run --name agent-postgres -e POSTGRES_PASSWORD=agent123 -p 5432:5432 -d postgres:14
```

### 2. Создание базы данных
```sql
-- Подключиться к PostgreSQL как суперпользователь
CREATE DATABASE agent_memory;
CREATE USER agent_user WITH PASSWORD 'agent_password';
GRANT ALL PRIVILEGES ON DATABASE agent_memory TO agent_user;
```

### 3. Настройка подключения в агенте

#### Через UI (http://localhost:7864):
```
Пользователь: Подключи базу данных agent_memory на localhost с пользователем agent_user

Агент: [Поможет настроить подключение]
```

#### Через API:
```bash
curl -X POST http://localhost:8001/tools/db_add_connection \
  -H "Content-Type: application/json" \
  -d '{
    "name": "agent_memory",
    "host": "localhost",
    "database": "agent_memory", 
    "user": "agent_user",
    "password": "agent_password",
    "port": 5432
  }'
```

### 4. Инициализация схемы памяти
```bash
curl -X POST http://localhost:8001/tools/memory_init \
  -H "Content-Type: application/json" \
  -d '{"connection_name": "agent_memory"}'
```

## 🗄️ Структура БД памяти

После инициализации создаются таблицы:

### `agent_sessions` - Сессии диалогов
- `session_id` - ID сессии
- `user_id` - ID пользователя  
- `created_at` - Время создания
- `last_activity` - Последняя активность
- `message_count` - Количество сообщений
- `metadata` - Дополнительные данные (JSON)

### `agent_messages` - Сообщения
- `id` - Уникальный ID сообщения
- `session_id` - Ссылка на сессию
- `role` - Роль (user, assistant, system, tool)
- `content` - Содержимое сообщения
- `timestamp` - Время сообщения
- `metadata` - Метаданные (JSON)

### `agent_project_context` - Контекст проектов
- `session_id` - Ссылка на сессию
- `project_name` - Название проекта
- `working_directory` - Рабочая директория
- `active_files` - Активные файлы (JSON)
- `project_metadata` - Метаданные проекта (JSON)

### `agent_knowledge` - База знаний
- `session_id` - Ссылка на сессию
- `knowledge_type` - Тип знания (fact, preference, skill)
- `key_name` - Ключ знания
- `value_data` - Данные (JSON)
- `confidence` - Уровень уверенности
- `source` - Источник знания
- `expires_at` - Время истечения

## 🔍 Возможности PostgreSQL памяти

### 1. **Полнотекстовый поиск**
```sql
-- Поиск по содержимому сообщений
SELECT * FROM agent_messages 
WHERE to_tsvector('russian', content) @@ plainto_tsquery('russian', 'PostgreSQL');
```

### 2. **Аналитика диалогов**
```sql
-- Статистика по сессиям
SELECT 
    COUNT(*) as total_sessions,
    AVG(message_count) as avg_messages,
    MAX(last_activity) as last_activity
FROM agent_sessions;
```

### 3. **База знаний**
```sql
-- Знания пользователя
SELECT knowledge_type, key_name, value_data 
FROM agent_knowledge 
WHERE session_id = 'user_session_123';
```

## 🎯 Преимущества PostgreSQL памяти

### ✅ **Масштабируемость**
- Миллионы сообщений без потери производительности
- Эффективные индексы для быстрого поиска
- Партиционирование по времени

### ✅ **Надежность**
- ACID транзакции
- Репликация и бэкапы
- Восстановление после сбоев

### ✅ **Мощный поиск**
- Полнотекстовый поиск с ранжированием
- Поиск по метаданным (JSON)
- Сложные аналитические запросы

### ✅ **Структурированные данные**
- Типизированные поля
- Связи между таблицами
- Ограничения целостности

## 🔧 Troubleshooting

### Проблема: "No connection found"
**Решение:** Настройте подключение к БД через API или UI

### Проблема: "psycopg2 not installed"
**Решение:** `pip install psycopg2-binary`

### Проблема: "Connection refused"
**Решение:** Проверьте, что PostgreSQL запущен и доступен

### Проблема: "Permission denied"
**Решение:** Проверьте права пользователя в PostgreSQL

## 🚀 Готово к использованию!

После настройки агент получает:

- 🧠 **Долговременную память** - помнит все диалоги
- 🔍 **Умный поиск** - находит информацию в истории  
- 📊 **Базу знаний** - накапливает факты о пользователе
- 📈 **Аналитику** - статистика использования
- 🔄 **Контекст проектов** - помнит рабочие файлы

**Агент становится по-настоящему умным помощником с памятью!** 🎉